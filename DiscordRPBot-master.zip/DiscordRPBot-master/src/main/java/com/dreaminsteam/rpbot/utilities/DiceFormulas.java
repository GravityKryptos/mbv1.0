package com.dreaminsteam.rpbot.utilities;

public class DiceFormulas {

}
