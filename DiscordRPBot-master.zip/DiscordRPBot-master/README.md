# DiscordRPBot
Super early stages of a discord roleplaying bot.

If you want to test it out yourself, it relies on a Secrets.properties file having been created in the src/main/resources folder.  All it needs currently is a Discord bot user token.  Running the application without the secrets file will tell you the format/key name.
